<?php
namespace App\Exception;

class NotFoundException extends FrameworkException
{

}
