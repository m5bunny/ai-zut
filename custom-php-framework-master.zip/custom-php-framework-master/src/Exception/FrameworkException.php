<?php
namespace App\Exception;

class FrameworkException extends \Exception
{

}
