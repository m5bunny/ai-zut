<?php
$config = [];
$config['db_dsn'] = 'sqlite:/path/to/data.db';
$config['db_user'] = '';
$config['db_pass'] = '';
